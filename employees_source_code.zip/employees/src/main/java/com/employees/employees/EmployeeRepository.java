package com.employees.employees;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	@Query("SELECT e FROM Employee e WHERE e.firstName LIKE %?1%"
			+"OR e.lastName LIKE %?1%"
			+"OR e.email LIKE %?1%")
	public List<Employee> findAll(String keyword);
}
